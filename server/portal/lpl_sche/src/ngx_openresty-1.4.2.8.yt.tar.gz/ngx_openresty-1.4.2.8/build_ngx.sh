./configure --prefix=/opt/interlive --with-luajit
make
make install